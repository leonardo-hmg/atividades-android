# Roteiro de teste manual — CineList

1. Inicie o app e aguarde a Splash avançar automaticamente para Login.
2. Digite um nome e entre na coleção.
3. Na aba Início, pesquise por título ou gênero.
4. Abra dois filmes diferentes e confira título, gênero, duração e sinopse.
5. Adicione um filme aos favoritos pelo coração no cartão ou pela tela de detalhes.
6. Abra Favoritos e confirme que o filme aparece.
7. Remova o filme e confirme que a lista vazia é exibida quando não houver nenhum favorito.
8. Na aba Início, role a lista, vá a outra aba e volte para conferir se a posição foi preservada.
9. Abra Perfil e use Sair da conta para retornar ao Login.
