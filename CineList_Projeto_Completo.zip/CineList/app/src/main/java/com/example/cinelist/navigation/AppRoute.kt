package com.example.cinelist.navigation

import kotlinx.serialization.Serializable

/** Todas as rotas são tipos serializáveis; não há rotas declaradas como String. */
@Serializable
sealed interface AppRoute

@Serializable
data object SplashRoute : AppRoute

@Serializable
data object LoginRoute : AppRoute

@Serializable
data object MainGraph : AppRoute

@Serializable
data object HomeTab : AppRoute

@Serializable
data object FavoritesTab : AppRoute

@Serializable
data object ProfileTab : AppRoute

@Serializable
data class MovieDetailRoute(val movieId: Int) : AppRoute
