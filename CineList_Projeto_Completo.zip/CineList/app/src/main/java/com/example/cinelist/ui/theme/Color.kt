package com.example.cinelist.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta centralizada do CineList. As telas consomem as cores pelo MaterialTheme.
val Ink = Color(0xFF17242F)
val InkSoft = Color(0xFF40515E)
val Coral = Color(0xFFE56B54)
val Teal = Color(0xFF2F7775)
val Cream = Color(0xFFF6F5F2)
val Paper = Color(0xFFFFFFFF)
val Mist = Color(0xFFE8ECEB)
val Sand = Color(0xFFF1E5D6)
val PaleCoral = Color(0xFFF8E5DF)
val PaleTeal = Color(0xFFDDEBE8)
val Muted = Color(0xFF77838B)
