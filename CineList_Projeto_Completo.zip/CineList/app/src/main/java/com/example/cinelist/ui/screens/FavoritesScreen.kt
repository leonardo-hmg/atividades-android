package com.example.cinelist.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cinelist.data.MoviesViewModel

@Composable
fun FavoritesScreen(
    viewModel: MoviesViewModel,
    onMovieClick: (Int) -> Unit,
    onExploreClick: () -> Unit
) {
    val listState = rememberLazyListState()
    val favorites = viewModel.favoriteMovies

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Column(modifier = Modifier.padding(top = 24.dp, bottom = 18.dp)) {
            Text(
                text = "SUA SELEÇÃO",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Meus favoritos",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = "Os filmes que merecem um lugar especial.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    EmptyState(
                        emoji = "🤍",
                        title = "Sua lista está vazia",
                        message = "Toque no coração de um filme para adicioná-lo aos seus favoritos."
                    )
                    androidx.compose.material3.Button(onClick = onExploreClick) {
                        Text("Explorar filmes")
                    }
                }
            }
        } else {
            Text(
                text = "${favorites.size} ${if (favorites.size == 1) "filme salvo" else "filmes salvos"}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(favorites, key = { it.id }) { movie ->
                    MovieCard(
                        movie = movie,
                        isFavorite = true,
                        onClick = { onMovieClick(movie.id) },
                        onFavoriteClick = { viewModel.toggleFavorite(movie.id) }
                    )
                }
            }
        }
    }
}
