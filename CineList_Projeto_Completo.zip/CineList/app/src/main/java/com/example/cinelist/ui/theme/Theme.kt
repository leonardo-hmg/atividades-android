package com.example.cinelist.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CineListColors = lightColorScheme(
    primary = Teal,
    onPrimary = Paper,
    primaryContainer = PaleTeal,
    onPrimaryContainer = Ink,
    secondary = Coral,
    onSecondary = Paper,
    secondaryContainer = PaleCoral,
    onSecondaryContainer = Ink,
    tertiary = InkSoft,
    onTertiary = Paper,
    tertiaryContainer = Sand,
    onTertiaryContainer = Ink,
    background = Cream,
    onBackground = Ink,
    surface = Paper,
    onSurface = Ink,
    surfaceVariant = Mist,
    onSurfaceVariant = InkSoft,
    outline = Muted
)

@Composable
fun CineListTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CineListColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
