package com.example.cinelist.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import androidx.navigation.hierarchy
import androidx.navigation.toRoute
import com.example.cinelist.data.MoviesViewModel
import com.example.cinelist.ui.screens.FavoritesScreen
import com.example.cinelist.ui.screens.HomeScreen
import com.example.cinelist.ui.screens.LoginScreen
import com.example.cinelist.ui.screens.MovieDetailScreen
import com.example.cinelist.ui.screens.ProfileScreen
import com.example.cinelist.ui.screens.SplashScreen

private enum class TabDestination { HOME, FAVORITES, PROFILE }

private data class BottomTab(
    val destination: TabDestination,
    val label: String,
    val contentDescription: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun CineListApp() {
    // O ViewModel é criado uma única vez no componente que hospeda o NavHost.
    // A mesma instância é passada para todas as telas que precisam do estado.
    val sharedViewModel: MoviesViewModel = viewModel()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val tabs = listOf(
        BottomTab(TabDestination.HOME, "Início", "Abrir início", Icons.Filled.Home),
        BottomTab(TabDestination.FAVORITES, "Favoritos", "Abrir favoritos", Icons.Filled.Favorite),
        BottomTab(TabDestination.PROFILE, "Perfil", "Abrir perfil", Icons.Filled.Person)
    )

    val shouldShowBottomBar = currentDestination?.hierarchy?.any { destination ->
        destination.hasRoute<HomeTab>() ||
            destination.hasRoute<FavoritesTab>() ||
            destination.hasRoute<ProfileTab>()
    } == true

    Scaffold(
        bottomBar = {
            if (shouldShowBottomBar) {
                NavigationBar {
                    tabs.forEach { tab ->
                        val selected = when (tab.destination) {
                            TabDestination.HOME -> currentDestination?.hasRoute<HomeTab>() == true
                            TabDestination.FAVORITES -> currentDestination?.hasRoute<FavoritesTab>() == true
                            TabDestination.PROFILE -> currentDestination?.hasRoute<ProfileTab>() == true
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigateTab(tab.destination)
                            },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.contentDescription
                                )
                            },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        CineListNavHost(
            navController = navController,
            viewModel = sharedViewModel,
            contentPadding = innerPadding
        )
    }
}

@Composable
private fun CineListNavHost(
    navController: NavHostController,
    viewModel: MoviesViewModel,
    contentPadding: PaddingValues
) {
    NavHost(
        navController = navController,
        startDestination = SplashRoute,
        modifier = Modifier.fillMaxSize().padding(contentPadding)
    ) {
        composable<SplashRoute> {
            SplashScreen(
                onFinished = {
                    // A Splash não conhece a regra de autenticação: quem a chama decide o destino.
                    if (viewModel.isLoggedIn) {
                        navController.navigate(MainGraph) {
                            popUpTo<SplashRoute> { inclusive = true }
                            launchSingleTop = true
                        }
                    } else {
                        navController.navigate(LoginRoute) {
                            popUpTo<SplashRoute> { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        composable<LoginRoute> {
            LoginScreen { name ->
                viewModel.login(name)
                navController.navigate(MainGraph) {
                    popUpTo<LoginRoute> { inclusive = true }
                    launchSingleTop = true
                }
            }
        }

        navigation<MainGraph>(startDestination = HomeTab) {
            composable<HomeTab> {
                HomeScreen(
                    viewModel = viewModel,
                    onMovieClick = { movieId ->
                        navController.navigate(MovieDetailRoute(movieId))
                    }
                )
            }

            composable<FavoritesTab> {
                FavoritesScreen(
                    viewModel = viewModel,
                    onMovieClick = { movieId ->
                        navController.navigate(MovieDetailRoute(movieId))
                    },
                    onExploreClick = { navController.navigateTab(TabDestination.HOME) }
                )
            }

            composable<ProfileTab> {
                ProfileScreen(
                    viewModel = viewModel,
                    onLogout = {
                        viewModel.logout()
                        navController.navigate(LoginRoute) {
                            popUpTo<MainGraph> { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable<MovieDetailRoute> { entry ->
                val route = entry.toRoute<MovieDetailRoute>()
                MovieDetailScreen(
                    movieId = route.movieId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

/**
 * Navegação das três abas com restauração do estado e prevenção de destinos duplicados.
 * saveState + restoreState preservam inclusive o estado salvo da rolagem da lista.
 */
private fun NavHostController.navigateTab(destination: TabDestination) {
    when (destination) {
        TabDestination.HOME -> navigate(HomeTab) {
            popUpTo<MainGraph> { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
        TabDestination.FAVORITES -> navigate(FavoritesTab) {
            popUpTo<MainGraph> { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
        TabDestination.PROFILE -> navigate(ProfileTab) {
            popUpTo<MainGraph> { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
}
