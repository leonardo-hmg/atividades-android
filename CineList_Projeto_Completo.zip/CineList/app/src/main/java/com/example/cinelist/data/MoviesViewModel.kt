package com.example.cinelist.data

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

/** Única fonte de estado compartilhada pelas telas do aplicativo. */
class MoviesViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = application.getSharedPreferences("cinelist-session", Context.MODE_PRIVATE)

    var isLoggedIn by mutableStateOf(preferences.getBoolean("logged_in", false))
        private set

    var userName by mutableStateOf(preferences.getString("user_name", "") ?: "")
        private set

    val movies: List<Movie> = sampleMovies

    var favoriteIds by mutableStateOf(setOf<Int>())
        private set

    val favoriteMovies: List<Movie>
        get() = movies.filter { it.id in favoriteIds }

    fun login(name: String) {
        userName = name.trim().ifBlank { "Cinéfilo" }
        isLoggedIn = true
        preferences.edit()
            .putBoolean("logged_in", true)
            .putString("user_name", userName)
            .apply()
    }

    fun logout() {
        isLoggedIn = false
        userName = ""
        preferences.edit()
            .putBoolean("logged_in", false)
            .remove("user_name")
            .apply()
    }

    fun toggleFavorite(movieId: Int) {
        favoriteIds = if (movieId in favoriteIds) {
            favoriteIds - movieId
        } else {
            favoriteIds + movieId
        }
    }

    fun findMovie(movieId: Int): Movie? = movies.firstOrNull { it.id == movieId }
}
