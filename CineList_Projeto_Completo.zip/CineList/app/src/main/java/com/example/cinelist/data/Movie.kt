package com.example.cinelist.data

data class Movie(
    val id: Int,
    val title: String,
    val year: Int,
    val genre: String,
    val duration: String,
    val rating: String,
    val synopsis: String,
    val posterEmoji: String,
    val tagline: String
)

val sampleMovies = listOf(
    Movie(
        id = 1,
        title = "Interestelar",
        year = 2014,
        genre = "Ficção científica",
        duration = "2h 49min",
        rating = "8,7",
        synopsis = "Em um futuro em que a Terra enfrenta uma crise ambiental, um grupo de exploradores parte em uma missão pelo espaço em busca de um novo lar para a humanidade. Uma jornada sobre ciência, coragem e os laços que atravessam o tempo.",
        posterEmoji = "🌌",
        tagline = "O amor é a única coisa que transcende o tempo e o espaço."
    ),
    Movie(
        id = 2,
        title = "A Origem",
        year = 2010,
        genre = "Suspense / Ficção",
        duration = "2h 28min",
        rating = "8,8",
        synopsis = "Um especialista em espionagem corporativa invade o subconsciente de seus alvos para roubar segredos. Sua missão mais difícil é plantar uma ideia, atravessando diferentes níveis de sonhos.",
        posterEmoji = "🌀",
        tagline = "Sua mente é o lugar da cena."
    ),
    Movie(
        id = 3,
        title = "Homem-Aranha: Através do Aranhaverso",
        year = 2023,
        genre = "Animação / Ação",
        duration = "2h 20min",
        rating = "8,6",
        synopsis = "Miles Morales encontra uma equipe de pessoas-aranha encarregada de proteger o multiverso. Quando surge um conflito sobre o destino de alguém que ama, ele precisa descobrir o que significa ser herói.",
        posterEmoji = "🕷️",
        tagline = "Mais de um universo. Mais de uma possibilidade."
    ),
    Movie(
        id = 4,
        title = "O Batman",
        year = 2022,
        genre = "Ação / Crime",
        duration = "2h 56min",
        rating = "7,8",
        synopsis = "Durante seu segundo ano como vigilante de Gotham, Batman investiga uma série de crimes que revelam uma rede de corrupção e o colocam frente a frente com um assassino enigmático.",
        posterEmoji = "🦇",
        tagline = "A justiça pode ser encontrada na escuridão."
    ),
    Movie(
        id = 5,
        title = "Duna: Parte Dois",
        year = 2024,
        genre = "Ficção científica",
        duration = "2h 46min",
        rating = "8,5",
        synopsis = "Paul Atreides se une aos Fremen em uma jornada de vingança e transformação no deserto de Arrakis, enquanto tenta impedir um futuro devastador que apenas ele consegue enxergar.",
        posterEmoji = "🏜️",
        tagline = "O destino não pode ser adiado."
    ),
    Movie(
        id = 6,
        title = "Whiplash",
        year = 2014,
        genre = "Drama / Música",
        duration = "1h 47min",
        rating = "8,5",
        synopsis = "Um jovem baterista entra em um conservatório de elite e passa a ser orientado por um professor brilhante e extremamente rigoroso. A busca pela excelência coloca os limites físicos e emocionais à prova.",
        posterEmoji = "🥁",
        tagline = "Até onde você iria para alcançar a grandeza?"
    ),
    Movie(
        id = 7,
        title = "Parasita",
        year = 2019,
        genre = "Drama / Suspense",
        duration = "2h 12min",
        rating = "8,5",
        synopsis = "Uma família que vive em condições difíceis encontra uma oportunidade de se aproximar de uma família rica. O plano parece perfeito, até que acontecimentos inesperados mudam completamente a situação.",
        posterEmoji = "🏠",
        tagline = "Uma história em que cada detalhe importa."
    ),
    Movie(
        id = 8,
        title = "Divertida Mente 2",
        year = 2024,
        genre = "Animação / Família",
        duration = "1h 36min",
        rating = "7,6",
        synopsis = "Com a chegada da adolescência, novas emoções aparecem na mente de Riley e transformam a rotina do centro de controle. Alegria e suas companheiras precisam aprender a conviver com as mudanças.",
        posterEmoji = "🎭",
        tagline = "Crescer é uma aventura cheia de emoções."
    )
)
