# CineList — Lista de Filmes Favoritos

Aplicativo Android desenvolvido em Kotlin com Jetpack Compose e Navigation Compose. O projeto atende à atividade **“Missão: Seu Próprio App, com Navegação de Verdade”**, usando o tema **Lista de Filmes Favoritos**.

## Tema escolhido

O CineList é um catálogo pessoal de filmes. A pessoa pode explorar títulos, pesquisar por nome ou gênero, abrir os detalhes de cada filme e salvar/remover títulos da lista de favoritos.

## Telas implementadas

1. **Splash:** abertura automática com animação simples.
2. **Login:** entrada demonstrativa com nome de usuário.
3. **Início:** catálogo de filmes, busca e acesso aos detalhes.
4. **Favoritos:** lista de filmes salvos e mensagem de estado vazio.
5. **Perfil:** resumo da coleção e opção para sair.
6. **Detalhes do filme:** sinopse, avaliação, duração, gênero e ação para favoritar.

A navegação principal possui três abas persistentes: **Início**, **Favoritos** e **Perfil**.

## Requisitos da atividade

| Requisito | Onde foi implementado |
|---|---|
| Rotas type-safe | `navigation/AppRoute.kt`: sealed interface com `@Serializable` e rotas tipadas. |
| Navegação linear | `SplashScreen` aguarda e chama `onFinished`, sem interação do usuário. |
| Navegação condicional | `navigation/CineListApp.kt` consulta o estado de login e decide entre `LoginRoute` e `MainGraph`. A decisão fica fora da Splash. |
| Parâmetro type-safe | `MovieDetailRoute(val movieId: Int)`; a tela recupera o argumento com `toRoute<MovieDetailRoute>()`. |
| Bottom Navigation persistente | `navigateTab()` usa `saveState`, `restoreState` e `launchSingleTop`. As listas usam `rememberLazyListState()`. |
| ViewModel único | `CineListApp()` cria uma única instância de `MoviesViewModel` e a compartilha com as telas. |
| Paleta própria | `ui/theme/Color.kt` e `ui/theme/Theme.kt`, com `lightColorScheme(...)`. |
| Estado vazio | `FavoritesScreen` mostra uma mensagem quando não existem favoritos; a busca também trata resultados vazios. |
| Acessibilidade básica | Os ícones possuem `contentDescription` descritivo. |

## Tecnologias

- Kotlin
- Jetpack Compose
- Material 3
- Navigation Compose com rotas type-safe
- Kotlin Serialization
- ViewModel

## Como executar no Android Studio

1. Extraia o arquivo ZIP.
2. Abra o Android Studio e selecione **Open**.
3. Escolha a pasta raiz `CineList` — a pasta que contém `settings.gradle.kts`.
4. Aguarde a sincronização do Gradle. Na primeira execução, é necessário ter conexão com a internet para baixar as dependências e a distribuição Gradle 8.9.
5. Confirme que o Android SDK 35 e o JDK 17 estão instalados no Android Studio.
6. Selecione um emulador ou conecte um dispositivo Android e pressione **Run**.

O projeto inclui os arquivos `gradlew` e `gradlew.bat` e um pequeno inicializador que baixa a distribuição Gradle indicada em `gradle/wrapper/gradle-wrapper.properties` quando ela ainda não está instalada.

### Acesso de demonstração

Na tela de login, informe qualquer nome e toque em **Entrar na minha coleção**. A sessão é guardada localmente no dispositivo para que a Splash consiga encaminhar uma pessoa já conectada diretamente ao painel em uma próxima abertura. Não existe autenticação real nem servidor: o login local serve para demonstrar o fluxo de navegação pedido na atividade.

## Estrutura do projeto

```text
CineList/
├── app/
│   └── src/main/
│       ├── java/com/example/cinelist/
│       │   ├── data/             # Modelo Movie e MoviesViewModel compartilhado
│       │   ├── navigation/       # Rotas serializáveis e NavHost
│       │   ├── ui/screens/       # Splash, Login, Início, Favoritos, Perfil e Detalhe
│       │   ├── ui/theme/         # Paleta e MaterialTheme
│       │   └── MainActivity.kt
│       └── AndroidManifest.xml
├── gradle/wrapper/
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Teste rápido antes da entrega

- [ ] Abrir o app do zero e confirmar Splash → Login.
- [ ] Entrar com um nome e confirmar que abre a aba Início.
- [ ] Abrir filmes diferentes e conferir se cada detalhe corresponde ao ID selecionado.
- [ ] Adicionar filmes aos favoritos e conferir a aba Favoritos.
- [ ] Remover todos os favoritos e conferir a mensagem de lista vazia.
- [ ] Rolar o catálogo, trocar de aba e voltar para conferir a restauração da rolagem.
- [ ] Abrir Perfil e testar Sair da conta.

## Publicação no GitHub

A atividade pede que o projeto completo seja enviado a um repositório público. Para isso, crie um repositório no GitHub, envie todo o conteúdo desta pasta e entregue o link desse repositório na plataforma indicada pelo professor. O arquivo ZIP é a cópia completa do projeto para essa etapa.
