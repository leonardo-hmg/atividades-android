package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small bootstrap launcher: downloads the configured Gradle distribution and forwards arguments. */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path projectDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
        Path propertiesFile = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesFile)) {
            throw new IllegalStateException("Arquivo gradle-wrapper.properties não encontrado: " + propertiesFile);
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(propertiesFile)) {
            properties.load(input);
        }

        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.isBlank()) {
            throw new IllegalStateException("distributionUrl não foi configurada no gradle-wrapper.properties.");
        }

        URI uri = URI.create(distributionUrl.replace("\\:", ":"));
        String archiveName = Paths.get(uri.getPath()).getFileName().toString();
        String distributionName = archiveName.endsWith(".zip")
                ? archiveName.substring(0, archiveName.length() - 4)
                : archiveName;

        String gradleUserHome = System.getenv("GRADLE_USER_HOME");
        Path userHome = gradleUserHome == null || gradleUserHome.isBlank()
                ? Paths.get(System.getProperty("user.home"), ".gradle")
                : Paths.get(gradleUserHome);
        Path installDir = userHome.resolve("wrapper/dists").resolve(distributionName).resolve("cinelist-bootstrap");
        Files.createDirectories(installDir);

        Path gradleExecutable = locateGradle(installDir, distributionName);
        if (gradleExecutable == null) {
            Path archive = installDir.resolve(archiveName);
            download(uri.toURL().toString(), archive);
            unzipSafely(archive, installDir);
            Files.deleteIfExists(archive);
            gradleExecutable = locateGradle(installDir, distributionName);
        }

        if (gradleExecutable == null) {
            throw new IllegalStateException("Não foi possível localizar o executável do Gradle após a extração.");
        }
        if (!isWindows()) {
            gradleExecutable.toFile().setExecutable(true);
        }

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/c");
            command.add(gradleExecutable.toString());
        } else {
            command.add(gradleExecutable.toString());
        }
        for (String argument : args) command.add(argument);

        Process process = new ProcessBuilder(command).directory(projectDir.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static Path locateGradle(Path installDir, String distributionName) throws IOException {
        String folderName = distributionName.replaceAll("-(bin|all)$", "");
        Path unix = installDir.resolve(folderName).resolve("bin/gradle");
        Path windows = installDir.resolve(folderName).resolve("bin/gradle.bat");
        if (isWindows()) {
            if (Files.isRegularFile(windows)) return windows;
            if (Files.isRegularFile(unix)) return unix;
        } else {
            if (Files.isRegularFile(unix)) return unix;
            if (Files.isRegularFile(windows)) return windows;
        }
        try (var paths = Files.walk(installDir, 5)) {
            return paths.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().equals(isWindows() ? "gradle.bat" : "gradle"))
                    .findFirst().orElse(null);
        }
    }

    private static void download(String address, Path target) throws IOException {
        System.out.println("Baixando distribuição do Gradle: " + address);
        HttpURLConnection connection = (HttpURLConnection) URI.create(address).toURL().openConnection();
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "CineList-Gradle-Bootstrap/1.0");
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
            throw new IOException("Falha ao baixar o Gradle. Código HTTP: " + status);
        }
        try (InputStream input = connection.getInputStream(); OutputStream output = Files.newOutputStream(target)) {
            input.transferTo(output);
        } finally {
            connection.disconnect();
        }
    }

    private static void unzipSafely(Path archive, Path destination) throws IOException {
        Path normalizedDestination = destination.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = normalizedDestination.resolve(entry.getName()).normalize();
                if (!output.startsWith(normalizedDestination)) {
                    throw new IOException("Entrada inválida encontrada no arquivo Gradle: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    try (OutputStream stream = Files.newOutputStream(output)) {
                        zip.transferTo(stream);
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
