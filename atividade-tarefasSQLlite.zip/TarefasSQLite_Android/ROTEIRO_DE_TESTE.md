# Roteiro de teste — Minhas Tarefas

Faça estes testes no emulador ou em um aparelho Android antes de enviar a atividade.

## 1. Primeira execução e cadastro

1. Instale e abra o aplicativo.
2. Confirme que a lista começa com a mensagem **Sua lista está vazia**.
3. Tente adicionar uma tarefa sem título e confirme que a validação informa que o título é obrigatório.
4. Cadastre uma tarefa com título e descrição.
5. Confirme que ela aparece na lista.

## 2. Operações da lista

1. Cadastre mais duas tarefas.
2. Marque uma tarefa como concluída e confirme que o checkbox e o texto refletem a mudança.
3. Exclua uma tarefa e confirme que ela desapareceu.
4. Exclua todas as tarefas e confirme que a mensagem de lista vazia aparece novamente.

## 3. Persistência real

1. Cadastre duas tarefas.
2. Feche o aplicativo completamente (remova-o da tela de aplicativos recentes).
3. Abra o aplicativo novamente.
4. Confirme que as tarefas continuam na lista e que o estado de conclusão foi mantido.

## 4. Revisão técnica

- [ ] `TaskDatabaseHelper` estende `SQLiteOpenHelper`.
- [ ] `onCreate()` executa o `CREATE TABLE` por `execSQL()`.
- [ ] `onUpgrade()` está implementado.
- [ ] Não há Room, SQLDelight nem biblioteca de persistência externa.
- [ ] Os pacotes `model`, `database`, `repository`, `viewmodel` e `ui` estão separados.
- [ ] `ContentValues` e `Cursor` são usados somente no Repository.
- [ ] O ViewModel não importa classes SQLite.
- [ ] As operações do Repository usam `suspend` e `Dispatchers.IO`.
- [ ] A interface usa Jetpack Compose e `LazyColumn`.
- [ ] Os dados continuam disponíveis depois de fechar e reabrir o app.
