package com.example.tarefassqlite.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Cria e atualiza o banco local usando exclusivamente SQLite nativo do Android. */
class TaskDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_TASKS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TITLE TEXT NOT NULL,
                $COLUMN_DESCRIPTION TEXT NOT NULL DEFAULT '',
                $COLUMN_COMPLETED INTEGER NOT NULL DEFAULT 0,
                $COLUMN_CREATED_AT INTEGER NOT NULL,
                $COLUMN_PRIORITY TEXT NOT NULL DEFAULT 'Normal'
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Migração de exemplo: a versão 2 acrescenta o campo de prioridade.
        // A tabela atual já é criada com esse campo nas instalações novas.
        if (oldVersion < 2) {
            db.execSQL(
                "ALTER TABLE $TABLE_TASKS ADD COLUMN $COLUMN_PRIORITY TEXT NOT NULL DEFAULT 'Normal'"
            )
        }
    }

    companion object {
        const val DATABASE_NAME = "tarefas_local.db"
        const val DATABASE_VERSION = 2
        const val TABLE_TASKS = "tasks"

        const val COLUMN_ID = "id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_COMPLETED = "is_completed"
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_PRIORITY = "priority"
    }
}
