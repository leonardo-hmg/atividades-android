package com.example.tarefassqlite.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import android.content.Context
import com.example.tarefassqlite.model.Task
import com.example.tarefassqlite.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface TaskUiState {
    data object Loading : TaskUiState
    data class Success(val tasks: List<Task>) : TaskUiState
    data class Error(val message: String) : TaskUiState
}

class TaskViewModel(private val repository: TaskRepository) : ViewModel() {
    private val _uiState = MutableStateFlow<TaskUiState>(TaskUiState.Loading)
    val uiState: StateFlow<TaskUiState> = _uiState.asStateFlow()

    init {
        loadTasks()
    }

    fun loadTasks() {
        viewModelScope.launch {
            _uiState.value = TaskUiState.Loading
            runCatching { repository.getAllTasks() }
                .onSuccess { tasks -> _uiState.value = TaskUiState.Success(tasks) }
                .onFailure { error ->
                    _uiState.value = TaskUiState.Error(
                        error.message ?: "Não foi possível carregar as tarefas."
                    )
                }
        }
    }

    fun addTask(title: String, description: String) {
        val cleanTitle = title.trim()
        val cleanDescription = description.trim()
        if (cleanTitle.isBlank()) {
            _uiState.value = TaskUiState.Error("Digite um título para a tarefa.")
            return
        }

        viewModelScope.launch {
            _uiState.value = TaskUiState.Loading
            runCatching {
                repository.insertTask(
                    Task(title = cleanTitle, description = cleanDescription)
                )
                repository.getAllTasks()
            }.onSuccess { tasks ->
                _uiState.value = TaskUiState.Success(tasks)
            }.onFailure { error ->
                _uiState.value = TaskUiState.Error(
                    error.message ?: "Não foi possível salvar a tarefa."
                )
            }
        }
    }

    fun setTaskCompleted(taskId: Long, completed: Boolean) {
        viewModelScope.launch {
            runCatching {
                repository.updateTaskCompletion(taskId, completed)
                repository.getAllTasks()
            }.onSuccess { tasks ->
                _uiState.value = TaskUiState.Success(tasks)
            }.onFailure { error ->
                _uiState.value = TaskUiState.Error(
                    error.message ?: "Não foi possível atualizar a tarefa."
                )
            }
        }
    }

    fun deleteTask(taskId: Long) {
        viewModelScope.launch {
            runCatching {
                repository.deleteTask(taskId)
                repository.getAllTasks()
            }.onSuccess { tasks ->
                _uiState.value = TaskUiState.Success(tasks)
            }.onFailure { error ->
                _uiState.value = TaskUiState.Error(
                    error.message ?: "Não foi possível excluir a tarefa."
                )
            }
        }
    }

    override fun onCleared() {
        repository.close()
        super.onCleared()
    }
}

class TaskViewModelFactory(context: Context) : ViewModelProvider.Factory {
    private val appContext = context.applicationContext

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            return TaskViewModel(TaskRepository(appContext)) as T
        }
        throw IllegalArgumentException("ViewModel desconhecido: ${modelClass.name}")
    }
}
