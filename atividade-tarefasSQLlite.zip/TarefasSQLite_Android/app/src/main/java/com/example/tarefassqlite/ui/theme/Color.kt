package com.example.tarefassqlite.ui.theme

import androidx.compose.ui.graphics.Color

val Forest = Color(0xFF176B55)
val ForestDark = Color(0xFF0E4D3D)
val Mint = Color(0xFFDDF4E9)
val Canvas = Color(0xFFF5F8F6)
val Ink = Color(0xFF17231E)
val Muted = Color(0xFF66756D)
val Coral = Color(0xFFC65D4B)
val White = Color(0xFFFFFFFF)
