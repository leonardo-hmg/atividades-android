package com.example.tarefassqlite.repository

import android.content.ContentValues
import android.content.Context
import com.example.tarefassqlite.database.TaskDatabaseHelper
import com.example.tarefassqlite.model.Task
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Única camada que manipula registros: ContentValues e Cursor ficam isolados aqui. */
class TaskRepository(context: Context) {
    private val databaseHelper = TaskDatabaseHelper(context.applicationContext)

    suspend fun getAllTasks(): List<Task> = withContext(Dispatchers.IO) {
        val tasks = mutableListOf<Task>()
        val database = databaseHelper.readableDatabase
        val cursor = database.query(
            TaskDatabaseHelper.TABLE_TASKS,
            arrayOf(
                TaskDatabaseHelper.COLUMN_ID,
                TaskDatabaseHelper.COLUMN_TITLE,
                TaskDatabaseHelper.COLUMN_DESCRIPTION,
                TaskDatabaseHelper.COLUMN_COMPLETED,
                TaskDatabaseHelper.COLUMN_CREATED_AT
            ),
            null,
            null,
            null,
            null,
            "${TaskDatabaseHelper.COLUMN_CREATED_AT} DESC"
        )

        cursor.use {
            val idIndex = it.getColumnIndexOrThrow(TaskDatabaseHelper.COLUMN_ID)
            val titleIndex = it.getColumnIndexOrThrow(TaskDatabaseHelper.COLUMN_TITLE)
            val descriptionIndex = it.getColumnIndexOrThrow(TaskDatabaseHelper.COLUMN_DESCRIPTION)
            val completedIndex = it.getColumnIndexOrThrow(TaskDatabaseHelper.COLUMN_COMPLETED)
            val createdAtIndex = it.getColumnIndexOrThrow(TaskDatabaseHelper.COLUMN_CREATED_AT)

            while (it.moveToNext()) {
                tasks += Task(
                    id = it.getLong(idIndex),
                    title = it.getString(titleIndex),
                    description = it.getString(descriptionIndex),
                    isCompleted = it.getInt(completedIndex) == 1,
                    createdAt = it.getLong(createdAtIndex)
                )
            }
        }
        tasks
    }

    suspend fun insertTask(task: Task): Long = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(TaskDatabaseHelper.COLUMN_TITLE, task.title)
            put(TaskDatabaseHelper.COLUMN_DESCRIPTION, task.description)
            put(TaskDatabaseHelper.COLUMN_COMPLETED, if (task.isCompleted) 1 else 0)
            put(TaskDatabaseHelper.COLUMN_CREATED_AT, task.createdAt)
        }
        databaseHelper.writableDatabase.insert(TaskDatabaseHelper.TABLE_TASKS, null, values)
    }

    suspend fun updateTaskCompletion(taskId: Long, isCompleted: Boolean): Int =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put(TaskDatabaseHelper.COLUMN_COMPLETED, if (isCompleted) 1 else 0)
            }
            databaseHelper.writableDatabase.update(
                TaskDatabaseHelper.TABLE_TASKS,
                values,
                "${TaskDatabaseHelper.COLUMN_ID} = ?",
                arrayOf(taskId.toString())
            )
        }

    suspend fun deleteTask(taskId: Long): Int = withContext(Dispatchers.IO) {
        databaseHelper.writableDatabase.delete(
            TaskDatabaseHelper.TABLE_TASKS,
            "${TaskDatabaseHelper.COLUMN_ID} = ?",
            arrayOf(taskId.toString())
        )
    }

    fun close() = databaseHelper.close()
}
