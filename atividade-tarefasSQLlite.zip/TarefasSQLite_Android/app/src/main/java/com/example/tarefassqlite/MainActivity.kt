package com.example.tarefassqlite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tarefassqlite.ui.TaskScreen
import com.example.tarefassqlite.ui.theme.TarefasSQLiteTheme
import com.example.tarefassqlite.viewmodel.TaskViewModel
import com.example.tarefassqlite.viewmodel.TaskViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TarefasSQLiteTheme {
                val taskViewModel: TaskViewModel = viewModel(
                    factory = TaskViewModelFactory(applicationContext)
                )
                TaskScreen(viewModel = taskViewModel)
            }
        }
    }
}
