package com.example.tarefassqlite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val AppColorScheme = lightColorScheme(
    primary = Forest,
    onPrimary = White,
    primaryContainer = Mint,
    onPrimaryContainer = ForestDark,
    secondary = Coral,
    onSecondary = White,
    background = Canvas,
    onBackground = Ink,
    surface = White,
    onSurface = Ink,
    surfaceVariant = Mint,
    onSurfaceVariant = Muted,
    error = Coral,
    onError = White
)

@Composable
fun TarefasSQLiteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
