package com.example.tarefassqlite.model

/** Representa uma tarefa armazenada localmente no SQLite. */
data class Task(
    val id: Long = 0L,
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
