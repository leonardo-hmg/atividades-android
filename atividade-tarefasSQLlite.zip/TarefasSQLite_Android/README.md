# Minhas Tarefas — SQLite Nativo

Aplicativo Android de cadastro e organização de tarefas, desenvolvido em Kotlin e Jetpack Compose. Os dados são guardados no próprio dispositivo usando SQLite nativo, sem Room, SQLDelight ou outras bibliotecas de persistência.

## Tema escolhido

**Lista de Tarefas**.

## Telas e funcionalidades

- Formulário para cadastrar tarefas com título e descrição opcional.
- Lista de tarefas salvas, exibida com `LazyColumn`.
- Marcação de tarefa como concluída.
- Exclusão de tarefas.
- Mensagem amigável quando a lista está vazia e tratamento de erros.
- Persistência local: as tarefas permanecem salvas depois de fechar e abrir novamente o aplicativo.

## Arquitetura

O código está separado nos pacotes exigidos no enunciado:

- `model`: classe `Task`, que representa uma tarefa.
- `database`: `TaskDatabaseHelper`, que estende `SQLiteOpenHelper`, cria a tabela com `CREATE TABLE` dentro de `onCreate()` e implementa `onUpgrade()`.
- `repository`: `TaskRepository`, única camada que manipula `ContentValues` e `Cursor` e que isola as operações de SQLite.
- `viewmodel`: `TaskViewModel`, que expõe os estados da tela por meio de uma `sealed interface` e executa as ações usando `viewModelScope`.
- `ui`: interface em Jetpack Compose, incluindo formulário e lista `LazyColumn`.

Todas as operações de leitura e escrita do banco são funções `suspend` executadas em `Dispatchers.IO` dentro do Repository. O ViewModel não importa `ContentValues`, `Cursor` ou `SQLiteDatabase`.

## Como executar no Android Studio

1. Extraia o arquivo ZIP do projeto.
2. Abra a pasta `TarefasSQLite_Android` no Android Studio usando **Open**.
3. Aguarde a sincronização do Gradle e a instalação das dependências do Android/Compose.
4. Inicie um emulador Android ou conecte um dispositivo com depuração USB ativada.
5. Clique em **Run** para instalar e executar o aplicativo.

**Requisitos de desenvolvimento:** Android Studio com suporte a projetos Gradle, JDK 17 e Android SDK 35. A primeira sincronização precisa de acesso à internet para baixar as dependências do Gradle.

## Persistência

O banco local chama-se `tarefas_local.db` e a tabela chama-se `tasks`. O banco é criado automaticamente na primeira execução. Não é necessário configurar servidor, conta ou conexão com a internet para cadastrar e consultar tarefas.

## Dependências

O projeto usa AndroidX, Jetpack Compose e Kotlin Coroutines. Não foi adicionada nenhuma biblioteca externa de persistência: o armazenamento é feito com as classes nativas `SQLiteOpenHelper`, `ContentValues`, `Cursor` e `SQLiteDatabase`.
