# Roteiro de teste — Minhas Tarefas (Room + JSONPlaceholder)

## 0. Atualização do banco anterior (quando já houver dados instalados)

1. Instale/execute a versão anterior da atividade SQLite e crie algumas tarefas.
2. Instale a versão atualizada do mesmo aplicativo por cima, mantendo o mesmo `applicationId`.
3. Confirme que as tarefas locais anteriores continuam aparecendo após a migração Room.

## 1. Primeira sincronização

1. Abra o aplicativo com a internet ativa.
2. Aguarde a sincronização com JSONPlaceholder.
3. Confirme que a lista é preenchida com tarefas da API.
4. Verifique se as tarefas importadas indicam `JSONPlaceholder`.

## 2. Cadastro local

1. Cadastre uma tarefa com título e descrição.
2. Confirme que ela aparece identificada como criada neste aparelho.
3. Marque e desmarque a tarefa.
4. Exclua uma tarefa e confirme que ela saiu da lista.

## 3. Teste offline-first

1. Depois da primeira sincronização, ative o modo avião.
2. Feche o aplicativo completamente e abra novamente.
3. Confirme que as tarefas já sincronizadas continuam visíveis.
4. Cadastre uma tarefa local e confirme que ela também fica salva.

## 4. Erro de rede sem perda de dados

1. Com o modo avião ativo, toque no botão de sincronizar.
2. Confirme que aparece o aviso de falha de conexão.
3. Confira se as tarefas anteriormente salvas continuam na tela.
4. Desative o modo avião e tente sincronizar novamente.

## 5. Verificação da arquitetura

- `model/TaskEntity.kt` declara a entidade Room.
- `database/TaskDao.kt` define as consultas e operações do banco.
- `database/TaskDatabase.kt` declara o banco Room.
- `network/` contém Retrofit e a interface da JSONPlaceholder.
- `repository/` é responsável por observar o Room e buscar/gravar dados da API.
- `viewmodel/TaskViewModel.kt` estende `AndroidViewModel` e expõe o Flow como `StateFlow`.
- `SyncStatus` trata apenas `Idle`, `Loading` e `Error`, separado da lista.
- As classes de `ui` e `viewmodel` não importam diretamente Retrofit nem classes da biblioteca Room.
