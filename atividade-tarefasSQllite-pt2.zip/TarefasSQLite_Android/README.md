# Minhas Tarefas — evolução para Room + JSONPlaceholder

Este projeto é a **continuação da atividade “Sua Própria Base de Dados”**, mantendo o aplicativo de Lista de Tarefas e evoluindo sua persistência do SQLite nativo para Room. O app também consulta a API pública JSONPlaceholder (`/todos`) e grava as tarefas recebidas no banco local.

## API escolhida

- **JSONPlaceholder — `/todos`**: https://jsonplaceholder.typicode.com/todos
- API pública, gratuita e sem necessidade de cadastro ou chave.
- A resposta JSON é mapeada pela `TodoDto`, usando `@SerializedName` para os campos `userId`, `id`, `title` e `completed`.

## Funcionalidades

- Exibe as tarefas a partir do banco local Room.
- Sincroniza tarefas da JSONPlaceholder automaticamente ao abrir e também pelo botão de atualizar.
- Permite cadastrar tarefas locais com título e descrição.
- Permite marcar tarefas como concluídas e excluí-las.
- Mostra carregamento e aviso quando a sincronização falha.
- Mantém as tarefas salvas visíveis quando o aparelho está sem internet.
- Evita duplicar tarefas remotas nas sincronizações seguintes.

## Arquitetura

```text
com.example.tarefassqlite/
├── model/        TaskEntity (Room) e TodoDto (JSON da API)
├── database/     TaskDao e TaskDatabase
├── network/      TodoApiService e RetrofitClient
├── repository/   Flow do Room + busca e gravação da API
├── viewmodel/    AndroidViewModel, StateFlow e SyncStatus
└── ui/           Tela Jetpack Compose e tema visual
```

### Single Source of Truth e offline-first

A interface observa somente `TaskRepository.observeTasks()`, que fornece um `Flow<List<TaskEntity>>` do Room. A API não entrega dados diretamente à tela: o método `syncFromApi()` consulta a JSONPlaceholder com Retrofit e grava os resultados no banco local.

O `TaskViewModel` estende `AndroidViewModel`, coleta o Flow do Repository como `StateFlow` e mantém o estado de sincronização separado dos dados, por meio de `SyncStatus` (`Idle`, `Loading` e `Error`). Uma falha de rede altera apenas o status e mostra um aviso; ela não apaga as tarefas já salvas.

As operações de acesso ao banco e sincronização são executadas em `Dispatchers.IO`. A inserção remota usa `OnConflictStrategy.IGNORE` e um `remoteId` único para não duplicar registros. Os recursos de cadastro, conclusão e exclusão da atividade anterior continuam disponíveis. O banco mantém o nome `tarefas_local.db` e declara migrações Room das versões 1→2 e 2→3: a atualização da versão 2 do SQLite nativo acrescenta apenas os campos de sincronização, preservando título, descrição, conclusão, data de criação e prioridade das tarefas que já existiam.

## Como executar no Android Studio

1. Extraia o ZIP.
2. Abra a pasta `TarefasSQLite_Android` no Android Studio.
3. Use JDK 17 e aguarde a sincronização do Gradle.
4. Execute em um emulador ou dispositivo Android com acesso à internet.
5. Na primeira abertura, aguarde a sincronização da JSONPlaceholder. Depois, ative o modo avião e confirme que as tarefas continuam aparecendo.

## Dependências principais

- Kotlin e Jetpack Compose
- Room (`room-runtime`, `room-ktx` e KSP compiler)
- Retrofit e Gson
- Kotlin Coroutines e AndroidX Lifecycle

**Persistência:** o projeto usa Room. O código antigo com `SQLiteOpenHelper`, `ContentValues` e `Cursor` foi substituído por `@Entity`, `@Dao` e `@Database`.
