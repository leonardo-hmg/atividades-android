package com.example.tarefassqlite.model

import com.google.gson.annotations.SerializedName

/** Modelo usado somente para converter o JSON recebido da API. */
data class TodoDto(
    @SerializedName("userId") val userId: Int,
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("completed") val completed: Boolean
)
