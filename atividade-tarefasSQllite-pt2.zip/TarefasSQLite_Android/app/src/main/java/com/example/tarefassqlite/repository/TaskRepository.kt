package com.example.tarefassqlite.repository

import com.example.tarefassqlite.database.TaskDao
import com.example.tarefassqlite.model.TaskEntity
import com.example.tarefassqlite.network.TodoApiService
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import retrofit2.HttpException

/** Erro de sincronização convertido para uma mensagem que não expõe Retrofit ao ViewModel. */
class SyncFailure(
    val displayMessage: String,
    cause: Throwable? = null
) : Exception(displayMessage, cause)

/**
 * Single Source of Truth: a tela observa exclusivamente o Flow do Room.
 * A API é usada somente para alimentar o banco local.
 */
class TaskRepository(
    private val dao: TaskDao,
    private val api: TodoApiService
) {
    /** Emite automaticamente a lista persistida sempre que o Room sofre alterações. */
    fun observeTasks(): Flow<List<TaskEntity>> = dao.observeAll()

    /** Busca tarefas remotas e as grava no Room, preservando registros existentes. */
    suspend fun syncFromApi(): Int = withContext(Dispatchers.IO) {
        try {
            val response = api.getTodos()
            val localEntities = response.map { todo ->
                TaskEntity(
                    title = todo.title,
                    description = "",
                    completed = todo.completed,
                    createdAt = System.currentTimeMillis(),
                    priority = "Normal",
                    remoteId = todo.id,
                    isFromApi = true
                )
            }
            // IGNORE evita duplicar a mesma tarefa remota em sincronizações futuras.
            dao.insertRemoteTasks(localEntities).count { rowId -> rowId != -1L }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (networkError: IOException) {
            throw SyncFailure(
                "Sem conexão com a internet. As tarefas já salvas continuam disponíveis.",
                networkError
            )
        } catch (httpError: HttpException) {
            throw SyncFailure(
                "O servidor retornou um erro (${httpError.code()}). As tarefas salvas foram preservadas.",
                httpError
            )
        } catch (error: Exception) {
            throw SyncFailure(
                "Não foi possível sincronizar agora. As tarefas salvas continuam disponíveis.",
                error
            )
        }
    }

    suspend fun addTask(title: String, description: String) = withContext(Dispatchers.IO) {
        dao.insertLocalTask(
            TaskEntity(
                title = title,
                description = description,
                completed = false,
                createdAt = System.currentTimeMillis(),
                priority = "Normal",
                isFromApi = false
            )
        )
    }

    suspend fun setCompleted(taskId: Long, completed: Boolean) = withContext(Dispatchers.IO) {
        dao.updateCompleted(taskId, completed)
    }

    suspend fun deleteTask(taskId: Long) = withContext(Dispatchers.IO) {
        dao.deleteById(taskId)
    }
}
