package com.example.tarefassqlite.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tarefassqlite.TaskApplication
import com.example.tarefassqlite.model.TaskEntity
import com.example.tarefassqlite.repository.SyncFailure
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** ViewModel Android que separa os dados observados do estado de sincronização. */
class TaskViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TaskApplication).taskRepository

    /** A lista vem do Flow do Repository/Room e é exposta como StateFlow. */
    val tasks: StateFlow<List<TaskEntity>> = repository.observeTasks().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    private val _syncStatus = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

    private val _syncMessage = MutableStateFlow<String?>(null)
    val syncMessage: StateFlow<String?> = _syncMessage.asStateFlow()

    init {
        // Sincroniza ao abrir; em paralelo, o Room continua entregando o cache local.
        syncTasks()
    }

    fun syncTasks() {
        if (_syncStatus.value == SyncStatus.Loading) return
        viewModelScope.launch {
            _syncMessage.value = null
            _syncStatus.value = SyncStatus.Loading
            try {
                val inserted = repository.syncFromApi()
                _syncMessage.value = if (inserted > 0) {
                    "$inserted novas tarefas foram sincronizadas e salvas no aparelho."
                } else {
                    "Sincronização concluída. As tarefas existentes foram mantidas."
                }
                _syncStatus.value = SyncStatus.Idle
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: SyncFailure) {
                _syncStatus.value = SyncStatus.Error(failure.displayMessage)
            } catch (error: Exception) {
                _syncStatus.value = SyncStatus.Error(
                    "Não foi possível sincronizar. As tarefas salvas continuam disponíveis."
                )
            }
        }
    }

    fun addTask(title: String, description: String) {
        val cleanTitle = title.trim()
        val cleanDescription = description.trim()
        if (cleanTitle.isEmpty()) return
        viewModelScope.launch {
            repository.addTask(cleanTitle, cleanDescription)
        }
    }

    fun setCompleted(task: TaskEntity, completed: Boolean) {
        viewModelScope.launch { repository.setCompleted(task.id, completed) }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch { repository.deleteTask(task.id) }
    }
}
