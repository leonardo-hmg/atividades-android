package com.example.tarefassqlite.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Tarefa persistida localmente no Room.
 * Os campos originais da atividade SQLite são mantidos; remoteId/isFromApi
 * identificam registros sincronizados com a JSONPlaceholder.
 */
@Entity(
    tableName = "tasks",
    indices = [Index(value = ["remote_id"], unique = true)]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    @ColumnInfo(defaultValue = "''")
    val description: String = "",
    @ColumnInfo(name = "is_completed", defaultValue = "0")
    val completed: Boolean = false,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'Normal'")
    val priority: String = "Normal",
    @ColumnInfo(name = "remote_id")
    val remoteId: Int? = null,
    @ColumnInfo(name = "is_from_api", defaultValue = "0")
    val isFromApi: Boolean = false
)
