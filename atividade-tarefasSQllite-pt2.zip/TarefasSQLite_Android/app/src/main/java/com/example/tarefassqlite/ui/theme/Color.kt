package com.example.tarefassqlite.ui.theme

import androidx.compose.ui.graphics.Color

val Forest = Color(0xFF226B4C)
val ForestDark = Color(0xFF164B36)
val Mint = Color(0xFFDCEFE3)
val Canvas = Color(0xFFF5F7F4)
val Ink = Color(0xFF1C2922)
val Muted = Color(0xFF64736B)
val Warning = Color(0xFF9B4C25)
val WarningSurface = Color(0xFFFFEDE4)
