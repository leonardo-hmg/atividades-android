package com.example.tarefassqlite.viewmodel

/** Estado da sincronização separado da lista persistida no Room. */
sealed interface SyncStatus {
    data object Idle : SyncStatus
    data object Loading : SyncStatus
    data class Error(val message: String) : SyncStatus
}
