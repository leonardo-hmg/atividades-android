package com.example.tarefassqlite

import android.app.Application
import com.example.tarefassqlite.database.TaskDatabase
import com.example.tarefassqlite.network.RetrofitClient
import com.example.tarefassqlite.repository.TaskRepository

/** Composition root: builds dependencies outside the ViewModel and UI layers. */
class TaskApplication : Application() {
    val taskRepository: TaskRepository by lazy {
        TaskRepository(
            dao = TaskDatabase.getInstance(this).taskDao(),
            api = RetrofitClient.todoApi
        )
    }
}
