package com.example.tarefassqlite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val AppColorScheme = lightColorScheme(
    primary = Forest,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = Mint,
    onPrimaryContainer = ForestDark,
    secondary = ForestDark,
    background = Canvas,
    surface = androidx.compose.ui.graphics.Color.White,
    onSurface = Ink,
    onSurfaceVariant = Muted,
    error = Warning,
    errorContainer = WarningSurface
)

@Composable
fun TarefasTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
