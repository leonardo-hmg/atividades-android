package com.example.tarefassqlite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.tarefassqlite.ui.TaskScreen
import com.example.tarefassqlite.ui.theme.TarefasTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TarefasTheme {
                TaskScreen()
            }
        }
    }
}
