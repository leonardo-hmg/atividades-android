package com.example.tarefassqlite.network

import com.example.tarefassqlite.model.TodoDto
import retrofit2.http.GET

interface TodoApiService {
    @GET("todos")
    suspend fun getTodos(): List<TodoDto>
}
