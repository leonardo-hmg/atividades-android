package com.example.viacep

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.viacep.ui.ConsultaCepScreen
import com.example.viacep.ui.theme.ViaCepTheme
import com.example.viacep.viewmodel.ConsultaCepViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ViaCepTheme {
                val consultaViewModel: ConsultaCepViewModel = viewModel()
                val estado = consultaViewModel.uiState.collectAsStateWithLifecycle()

                ConsultaCepScreen(
                    estado = estado.value,
                    onBuscarCep = consultaViewModel::buscarCep,
                    onLimparBusca = consultaViewModel::limparBusca
                )
            }
        }
    }
}
