package com.example.viacep.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColorScheme = lightColorScheme(
    primary = AzulPrincipal,
    onPrimary = Branco,
    primaryContainer = AzulClaro,
    onPrimaryContainer = AzulPetroleo,
    secondary = VerdeAgua,
    onSecondary = Branco,
    background = Fundo,
    onBackground = TextoPrincipal,
    surface = Branco,
    onSurface = TextoPrincipal,
    surfaceVariant = AzulClaro,
    onSurfaceVariant = TextoSecundario,
    error = VermelhoErro,
    onError = Color.White
)

@Composable
fun ViaCepTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
