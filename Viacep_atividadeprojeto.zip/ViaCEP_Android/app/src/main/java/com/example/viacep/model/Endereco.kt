package com.example.viacep.model

import com.google.gson.annotations.SerializedName

data class Endereco(
    @SerializedName("cep") val cep: String? = null,
    @SerializedName("logradouro") val logradouro: String? = null,
    @SerializedName("complemento") val complemento: String? = null,
    @SerializedName("unidade") val unidade: String? = null,
    @SerializedName("bairro") val bairro: String? = null,
    @SerializedName("localidade") val cidade: String? = null,
    @SerializedName("uf") val estado: String? = null,
    @SerializedName("estado") val nomeEstado: String? = null,
    @SerializedName("regiao") val regiao: String? = null,
    @SerializedName("ibge") val codigoIbge: String? = null,
    @SerializedName("gia") val codigoGia: String? = null,
    @SerializedName("ddd") val ddd: String? = null,
    @SerializedName("siafi") val codigoSiafi: String? = null,
    @SerializedName("erro") val erro: Boolean? = false
)
