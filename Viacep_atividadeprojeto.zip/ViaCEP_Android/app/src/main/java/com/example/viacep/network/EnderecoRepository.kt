package com.example.viacep.network

import com.example.viacep.model.Endereco

class EnderecoRepository(
    private val api: ViaCepApi = RetrofitClient.viaCepApi
) {
    suspend fun buscarEndereco(cep: String): Endereco {
        val endereco = api.consultarCep(cep)
        if (endereco.erro == true) {
            throw CepNaoEncontradoException()
        }
        return endereco
    }
}

class CepNaoEncontradoException : Exception("CEP não encontrado")
