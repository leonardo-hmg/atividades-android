package com.example.viacep.ui.theme

import androidx.compose.ui.graphics.Color

val AzulPetroleo = Color(0xFF123B4A)
val AzulPrincipal = Color(0xFF176B87)
val AzulClaro = Color(0xFFDCEFF4)
val VerdeAgua = Color(0xFF2A9D8F)
val Fundo = Color(0xFFF4F8FA)
val Branco = Color(0xFFFFFFFF)
val TextoPrincipal = Color(0xFF17313A)
val TextoSecundario = Color(0xFF617780)
val VermelhoErro = Color(0xFFB3261E)
val FundoErro = Color(0xFFFCEEEE)
