package com.example.viacep.network

import com.example.viacep.model.Endereco
import retrofit2.http.GET
import retrofit2.http.Path

interface ViaCepApi {
    @GET("{cep}/json/")
    suspend fun consultarCep(@Path("cep") cep: String): Endereco
}
