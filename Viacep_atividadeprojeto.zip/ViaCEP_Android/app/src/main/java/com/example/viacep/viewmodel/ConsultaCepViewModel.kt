package com.example.viacep.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.viacep.model.Endereco
import com.example.viacep.network.CepNaoEncontradoException
import com.example.viacep.network.EnderecoRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

sealed interface ConsultaCepUiState {
    data object Idle : ConsultaCepUiState
    data object Loading : ConsultaCepUiState
    data class Success(val endereco: Endereco) : ConsultaCepUiState
    data class Error(val mensagem: String) : ConsultaCepUiState
}

class ConsultaCepViewModel : ViewModel() {

    private val repository = EnderecoRepository()
    private val _uiState = MutableStateFlow<ConsultaCepUiState>(ConsultaCepUiState.Idle)
    val uiState: StateFlow<ConsultaCepUiState> = _uiState.asStateFlow()

    fun buscarCep(entrada: String) {
        val cep = entrada.filter(Char::isDigit)

        if (cep.length != 8) {
            _uiState.value = ConsultaCepUiState.Error(
                "Digite um CEP válido com exatamente 8 números."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = ConsultaCepUiState.Loading
            try {
                val endereco = repository.buscarEndereco(cep)
                _uiState.value = ConsultaCepUiState.Success(endereco)
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: CepNaoEncontradoException) {
                _uiState.value = ConsultaCepUiState.Error(
                    "Esse CEP não foi encontrado. Confira os números e tente novamente."
                )
            } catch (exception: IOException) {
                _uiState.value = ConsultaCepUiState.Error(
                    "Não foi possível conectar. Verifique sua internet e tente novamente."
                )
            } catch (exception: HttpException) {
                _uiState.value = ConsultaCepUiState.Error(
                    "O serviço ViaCEP está indisponível no momento. Tente novamente mais tarde."
                )
            } catch (exception: Exception) {
                _uiState.value = ConsultaCepUiState.Error(
                    "Ocorreu um erro inesperado. Tente novamente."
                )
            }
        }
    }

    fun limparBusca() {
        _uiState.value = ConsultaCepUiState.Idle
    }
}
