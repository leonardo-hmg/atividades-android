package com.example.viacep.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apartment
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.viacep.model.Endereco
import com.example.viacep.ui.theme.AzulClaro
import com.example.viacep.ui.theme.FundoErro
import com.example.viacep.ui.theme.TextoSecundario
import com.example.viacep.ui.theme.VermelhoErro
import com.example.viacep.viewmodel.ConsultaCepUiState

@Composable
fun ConsultaCepScreen(
    estado: ConsultaCepUiState,
    onBuscarCep: (String) -> Unit,
    onLimparBusca: () -> Unit
) {
    var cep by rememberSaveable { mutableStateOf("") }
    val carregando = estado is ConsultaCepUiState.Loading

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Cabecalho()
            CartaoBusca(
                cep = cep,
                onCepChange = { novoValor -> cep = novoValor.filter(Char::isDigit).take(8) },
                carregando = carregando,
                onBuscar = { onBuscarCep(cep) }
            )

            when (estado) {
                ConsultaCepUiState.Idle -> EstadoInicial()
                ConsultaCepUiState.Loading -> EstadoCarregando()
                is ConsultaCepUiState.Error -> EstadoErro(
                    mensagem = estado.mensagem,
                    onTentarNovamente = { onBuscarCep(cep) }
                )
                is ConsultaCepUiState.Success -> ResultadoEndereco(
                    endereco = estado.endereco,
                    onNovaBusca = {
                        cep = ""
                        onLimparBusca()
                    }
                )
            }

            Text(
                text = "Dados fornecidos pela API pública ViaCEP",
                style = MaterialTheme.typography.labelSmall,
                color = TextoSecundario,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun Cabecalho() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(AzulClaro),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.LocationOn,
                contentDescription = "Ícone de localização do aplicativo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(
                text = "Busca CEP",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Encontre um endereço pelo CEP",
                style = MaterialTheme.typography.bodyMedium,
                color = TextoSecundario
            )
        }
    }
}

@Composable
private fun CartaoBusca(
    cep: String,
    onCepChange: (String) -> Unit,
    carregando: Boolean,
    onBuscar: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Qual CEP você procura?",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Digite os 8 números do CEP para consultar o endereço completo.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextoSecundario
            )
            OutlinedTextField(
                value = cep,
                onValueChange = onCepChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("CEP") },
                placeholder = { Text("Ex.: 01001000") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Map,
                        contentDescription = "Campo para digitar o CEP"
                    )
                },
                trailingIcon = {
                    Text(
                        text = "${cep.length}/8",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextoSecundario,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    focusedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
            Button(
                onClick = onBuscar,
                enabled = !carregando,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(15.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = "Pesquisar CEP"
                )
                Spacer(Modifier.width(8.dp))
                Text("Consultar endereço", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun EstadoInicial() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier.size(70.dp).clip(CircleShape).background(AzulClaro),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Home,
                contentDescription = "Ilustração de endereço",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp)
            )
        }
        Text(
            text = "Seu próximo endereço começa aqui",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Text(
            text = "O resultado da consulta aparecerá nesta área.",
            style = MaterialTheme.typography.bodySmall,
            color = TextoSecundario,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun EstadoCarregando() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(22.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 3.dp)
            Spacer(Modifier.width(14.dp))
            Text("Consultando endereço...", color = TextoSecundario)
        }
    }
}

@Composable
private fun EstadoErro(mensagem: String, onTentarNovamente: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = FundoErro)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.WifiOff,
                contentDescription = "Ícone indicando falha na consulta",
                tint = VermelhoErro,
                modifier = Modifier.size(30.dp)
            )
            Text(
                text = "Não foi possível realizar a consulta",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = VermelhoErro,
                textAlign = TextAlign.Center
            )
            Text(
                text = mensagem,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            OutlinedButton(onClick = onTentarNovamente) {
                Text("Tentar novamente")
            }
        }
    }
}

@Composable
private fun ResultadoEndereco(endereco: Endereco, onNovaBusca: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = "Consulta realizada com sucesso",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(25.dp)
                )
                Spacer(Modifier.width(9.dp))
                Text(
                    text = "Endereço encontrado",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = endereco.cep ?: "CEP consultado",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            LinhaEndereco("Logradouro", endereco.logradouro)
            LinhaEndereco("Complemento", endereco.complemento)
            LinhaEndereco("Bairro", endereco.bairro)
            LinhaEndereco("Cidade", endereco.cidade, Icons.Outlined.Apartment)
            LinhaEndereco("Estado", listOfNotNull(endereco.nomeEstado, endereco.estado).joinToString(" — ").ifBlank { null })
            LinhaEndereco("Região", endereco.regiao)
            Button(
                onClick = onNovaBusca,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Fazer nova consulta", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun LinhaEndereco(
    titulo: String,
    valor: String?,
    icone: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icone != null) {
                Icon(
                    imageVector = icone,
                    contentDescription = "Campo $titulo",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(5.dp))
            }
            Text(
                text = titulo,
                style = MaterialTheme.typography.labelMedium,
                color = TextoSecundario
            )
        }
        Text(
            text = valor?.takeIf { it.isNotBlank() } ?: "Não informado",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )
    }
}
