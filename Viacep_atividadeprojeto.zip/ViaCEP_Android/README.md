# Busca CEP — Aplicativo Android

O **Busca CEP** é um aplicativo Android que consulta endereços brasileiros a partir de um CEP, utilizando a API pública e gratuita **ViaCEP**. A pessoa usuária informa os oito dígitos do CEP e visualiza logradouro, complemento, bairro, cidade, estado e outras informações retornadas pela API. O projeto foi desenvolvido com **Kotlin, Jetpack Compose, Retrofit, Gson e Coroutines**, seguindo a arquitetura MVVM com separação entre `model`, `network`, `viewmodel` e `ui`. Para executar, abra a pasta do projeto no Android Studio, aguarde a sincronização do Gradle e rode o módulo `app` em um emulador ou dispositivo Android com acesso à internet.

## API utilizada

- Nome: ViaCEP
- URL base: `https://viacep.com.br/ws/`
- Exemplo de consulta: `https://viacep.com.br/ws/01001000/json/`
- Documentação: https://viacep.com.br/

## Telas e funcionalidades

- Tela principal de consulta de CEP com entrada numérica limitada a oito dígitos.
- Estado de carregamento durante a chamada de rede.
- Resultado com CEP, logradouro, complemento, bairro, cidade, estado e região.
- Mensagens visíveis para CEP inválido, CEP não encontrado e falhas de conexão/servidor.
- Ação para limpar o resultado e iniciar uma nova consulta.

## Arquitetura do projeto

```text
com.example.viacep/
├── model/
│   └── Endereco.kt
├── network/
│   ├── ViaCepApi.kt
│   ├── RetrofitClient.kt
│   └── EnderecoRepository.kt
├── viewmodel/
│   └── ConsultaCepViewModel.kt
├── ui/
│   ├── ConsultaCepScreen.kt
│   └── theme/
│       ├── Color.kt
│       └── Theme.kt
└── MainActivity.kt
```

## Requisitos

- Android Studio com suporte a projetos Android Gradle.
- JDK 17.
- Android SDK 35 instalado pelo SDK Manager.
- Internet disponível no emulador/dispositivo para consultar a API.

## Como executar

1. Extraia o arquivo ZIP.
2. No Android Studio, selecione **Open** e escolha a pasta `ViaCEP_Android`.
3. Aguarde a sincronização do Gradle e a instalação das dependências.
4. Selecione um emulador ou conecte um dispositivo Android.
5. Execute a configuração `app` pelo botão **Run**.

## Testes manuais sugeridos

- CEP válido: `01001000`.
- CEP inexistente: `99999999`.
- Entrada incompleta: `1234`.
- Desative a internet e faça uma consulta para conferir a mensagem de erro.
- Faça uma consulta válida e gire o emulador para verificar a preservação do estado pelo ViewModel.

## Observação

O aplicativo precisa de internet para consultar a ViaCEP. A permissão `android.permission.INTERNET` já está declarada no `AndroidManifest.xml`.
