# Roteiro de teste — Busca CEP

## 1. Inicialização
- [ ] Abrir o projeto no Android Studio.
- [ ] Aguardar a sincronização do Gradle.
- [ ] Executar o app em um emulador ou dispositivo conectado à internet.
- [ ] Confirmar que a tela principal abre sem falhas.

## 2. Consulta válida
- [ ] Digitar `01001000`.
- [ ] Tocar em **Consultar endereço**.
- [ ] Verificar o estado de carregamento.
- [ ] Confirmar que os dados do endereço aparecem na tela.

## 3. Validação e falhas
- [ ] Digitar menos de oito números e consultar; deve aparecer uma mensagem de CEP inválido.
- [ ] Consultar `99999999`; deve aparecer uma mensagem de CEP não encontrado.
- [ ] Desligar a internet e tentar consultar; deve aparecer uma mensagem de falha de conexão, sem fechar o app.

## 4. Estado e rotação
- [ ] Fazer uma consulta válida.
- [ ] Girar o emulador/dispositivo.
- [ ] Conferir que o resultado continua na tela, mantido pelo ViewModel.
- [ ] Tocar em **Fazer nova consulta** e verificar que o resultado é limpo.

## 5. Conferência da arquitetura
- [ ] Confirmar que a UI recebe estado e callbacks, sem chamar Retrofit.
- [ ] Confirmar que a interface Retrofit possui método `suspend` anotado com `@GET`.
- [ ] Confirmar que o ViewModel dispara a busca dentro de `viewModelScope`.
- [ ] Confirmar que `Endereco` mapeia o JSON com `@SerializedName`.
- [ ] Confirmar que `ConsultaCepUiState` representa Idle, Loading, Success e Error.
- [ ] Confirmar que `AndroidManifest.xml` declara `android.permission.INTERNET`.
